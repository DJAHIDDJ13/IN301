#include <stdio.h>
#include <stdlib.h>
#include <dirent.h> 
#include "mes_types.h"
#include <string.h>
#include "lire_ecrire.h"
#include <uvsqgraphics.h>
void jouer_tout_les_niveaux()
{
	SLIDER S;
	DIR* rep = NULL;
    struct dirent* fichierLu = NULL; // Déclaration d'un pointeur vers la structure dirent. 
    rep = opendir("../projetc/niveaux");
    if (rep == NULL)
        exit(1);
      while ((fichierLu = readdir(rep)) != NULL)
      {
		printf("Le fichier lu s'appelle '%s'\n", fichierLu->d_name);
		if(fichierLu->d_name[0]!='.')
		{
			S=lire_fichier(fichierLu->d_name);
			initialiser_affichage(S);
			afficher_slider(S);
			deplace_slider(S);
			attendre(10);
			slider_rencontre_sortie(S);
		}
	  }
}

