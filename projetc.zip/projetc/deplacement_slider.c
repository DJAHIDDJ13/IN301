#include "mes_types.h"
#include <uvsqgraphics.h>
#include "afficher.h"
void efface_le_slider(SLIDER S) 
{
	POINT p1;
	p1.x=(S.positionslider_x)*50+25;
	p1.y=(S.positionslider_y)*50+25;
	draw_fill_circle(p1,25,noir);
}
int slider_rencontre_sortie(SLIDER S,int i)
{	
	if(((S.positionslider_x)==(S.positionsortie_x)) && ((S.positionslider_y)==(S.positionsortie_y)))
	{
		
		i=0;
		fill_screen(blanc);
		int taille_police = (S.H*50)/2;
		static char s[64] = "BINGO";
		POINT hg, hg1;
		
		hg1.x = (50*S.L)/2;
		hg1.y = (50*S.H)/2;
		aff_pol(s,taille_police,hg1,noir);
	    //wait_escape();
	    //exit(0);
		
		
		
	}
	
	return i;
	

}
 



void deplace_slider( SLIDER S)
{
	int ee;
	int a;
	int i=1;
	while(i!=0){
	ee=wait_key_arrow_clic (NULL, &a, NULL);
	if(ee==EST_FLECHE)
	{
		if(a==FLECHE_DROITE)
	    {
			while(S.plan[S.positionslider_x][S.positionslider_y][1]==0)
			{
			//deplacement_sortie(S);
				i=slider_rencontre_sortie(S,i);
				if(i!=0)
				{
				attendre(10);
				efface_le_slider(S);
				S.positionslider_x+=1;
				afficher_le_slider(S);
				}
			}
		}
		if(a==FLECHE_GAUCHE)
		{
		
			while(S.plan[S.positionslider_x][S.positionslider_y][3]==0)
			{
				i=slider_rencontre_sortie(S,i);
				if(i!=0)
				{
				attendre(60);
				efface_le_slider(S);
				S.positionslider_x-=1;
				afficher_le_slider(S);
				}
			}
		}

		if(a==FLECHE_HAUT)
		{
		
			while(S.plan[S.positionslider_x][S.positionslider_y][0]==0)
			{
				i=slider_rencontre_sortie(S,i);
				if(i!=0)
				{
				attendre(60);
				efface_le_slider(S);
				S.positionslider_y+=1;
				afficher_le_slider(S);
				}
			}
		}

		if(a==FLECHE_BAS)
		{
		
			while(S.plan[S.positionslider_x][S.positionslider_y][2]==0)
			{
				i=slider_rencontre_sortie(S,i);
				if(i!=0)
				{
				attendre(60);
				efface_le_slider(S);
				S.positionslider_y-=1;
				afficher_le_slider(S);
				}
			}
		}
	}


}
}


	
	
	
	

	

	


