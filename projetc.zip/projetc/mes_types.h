#define TAILLE_CASE 50



struct slider {
	int L,H; // Largeur et hauteur de la grille
	int positionslider_x;
	int positionslider_y;
	int positionsortie_x;
	int positionsortie_y;
	int ***plan;
	int nbr_mur;
};

typedef struct slider SLIDER;

struct element {
int x,y;
struct element *suivant;
	
};
typedef struct element element;

