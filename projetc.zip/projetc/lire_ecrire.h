SLIDER lire_fichier(char *nom);

void ecrire_fichier(SLIDER S, char*nom);

void liberer_memoire(SLIDER S);

int mur_externe(SLIDER S, int x, int y, int r);

void initialisation_murs_externes(SLIDER S);

SLIDER init_tab(SLIDER S);
