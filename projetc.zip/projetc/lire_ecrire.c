#include <stdio.h>
#include <stdlib.h>

#include "mes_types.h"


int mur_externe(SLIDER S, int x, int y, int r){
	if((x==0 && r==3)|| (y==0&& r==2))
		return 1;
	if((y==S.H-1 && r==0) || (x==S.L-1 && r==1))
		return 1;
	
		
		return 0;
	
}
SLIDER initialisation_murs_externes(SLIDER S)
{
	S.plan=malloc(sizeof(int**)*S.L);
	for(int i=0; i<S.L; i++)
	{
		S.plan[i]=malloc(sizeof(int*)*S.H);
		for(int j=0; j<S.H; j++)
		{
			S.plan[i][j]=malloc(sizeof(int)*4);
			for(int k=0; k<4; k++)
			{
				S.plan[i][j][k] = mur_externe(S, i, j, k);
				
			}
		}
	}
	return S;
}
SLIDER mur_case_associer(SLIDER S, int x, int y, int r){
	
	if(r == 0)
	{
		if(y+1<S.H)
			S.plan[x][y+1][2] = 1;
	}
	if(r == 3)
	{
		if(x+1<S.L)
			S.plan[x+1][y][3] = 1;
	}
	if(r == 6)
	{
		if(y-1>=0)
			S.plan[x][y-1][0] =1;
	}
	if(r == 9)
	{
		if(x-1>=0)
			S.plan[x-1][y][1] = 1;
	}	
	
	return S;
}
SLIDER init_tab(SLIDER S)
{
	S.plan=malloc(sizeof(int**)*S.L);
	for(int i=0; i<S.L; i++)
	{
		S.plan[i]=malloc(sizeof(int*)*S.H);
		for(int j=0; j<S.H; j++)
		{
			S.plan[i][j]=malloc(sizeof(int)*4);
			for(int k=0; k<4; k++)
			{
				S.plan[i][j][k] = 0;
				
			}
		}
	}
	return S;
}
SLIDER lire_fichier(char *nom) {

	SLIDER S;
	FILE *fic=fopen(nom,"r");
    if(fic==NULL)
		exit(1);
	int x=0,y=0,p=0;
	fscanf(fic,"%d%d%d%d",&S.L,&S.H,&S.positionslider_x,& S.positionslider_y);
	fscanf(fic,"%d%d%d",&S.positionsortie_x,&S.positionsortie_y,&S.nbr_mur);
	S=init_tab(S);
	S=initialisation_murs_externes(S);
	for(int i=0;i<S.nbr_mur;i++)
	{
		fscanf(fic,"%d%d%d",&x,&y,&p);
		S.plan[x][y][p/3] = 1;
		S =mur_case_associer(S,x,y,p);
		
	}
	fclose(fic);
	
	return S;
	           
}          

void liberer_memoire(SLIDER S)
{	   
	for(int i=0; i<S.L; i++)
	{
		for(int j=0; j<S.H; j++)
		{
			free(S.plan[i][j]);
		}
	}
	
	for(int i=0; i<S.L; i++)
	{
		free(S.plan[i]);
	}
		free(S.plan);
}	        
	           


void ecrire_fichier(SLIDER S,char *nom){
	
	FILE *fic=fopen(nom,"w");
    if(fic==NULL)
		exit(1);
	fprintf(fic,"%d%d\n%d%d\n",S.L,S.H,S.positionslider_x, S.positionslider_y);
	fprintf(fic,"%d%d\n%d",S.positionsortie_x,S.positionsortie_y,S.nbr_mur);
	/*S.plan=malloc(sizeof(int**)*S.L);
	initialisation_murs(S);*/
	
	fclose(fic);
}
