	void slider_rencontre_sortie(SLIDER S);
	void deplace_slider(SLIDER S);	

