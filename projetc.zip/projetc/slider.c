#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mes_types.h"
#include "eef.h"
#include "lire_ecrire.h"
#include "afficher.h"
#include "deplacement_slider.h"


int main (int argc, char*argv[]) {
	
	SLIDER S;
	
	char mot[]="niveaux";
	char mot2[]="-c";
	int a=strcmp(mot,argv[1]);
	int b=strcmp(mot2,argv[1]);
	if(a==0)
	{
		jouer_tout_les_niveaux();
    }
    if(b==0)
    {
		editeur(argv[2],argv[3]);
	}	
	else
	{
		S = lire_fichier(argv[1]);
		initialiser_affichage(S);
		afficher_slider(S);
		deplace_slider(S);
		slider_rencontre_sortie(S);
	}
	liberer_memoire(S);
	finir_affichage(S);
	//exit(0);
	
	
}
