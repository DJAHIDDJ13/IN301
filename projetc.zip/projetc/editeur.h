editeur(char*nom,char*nom2)
