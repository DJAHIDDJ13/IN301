#include <uvsqgraphics.h>
#include "mes_types.h"


void initialiser_affichage(SLIDER S) {
	
	init_graphics (50*S.L,50*S.H);
	
}

void afficher_grille(SLIDER S) 
{
	POINT p1,p2;
	int i=1;
	for(i=0;i<S.L;i++)
	{
		p1.x=50*i; p1.y=0;
		p2.x=50*i; p2.y=50*S.H;
		draw_line(p1,p2,bleu);
	}
	for(i=0;i<S.H;i++)
	{
		p1.x=0; p1.y=50*i;
		p2.x=50*S.L; p2.y=50*i;
		draw_line(p1,p2,bleu);
	}
}


void afficher_murs(SLIDER S) 
{
	for(int i=0; i<S.L; i++)
	{
		for(int j=0; j<S.H; j++)
		{
			if(S.plan[i][j][0]==1)
			{
				POINT p1,p2;
				p1.y=j*50+50;
				p2.y=p1.y;
				p1.x=i*50;
				p2.x=p1.x+50;
				draw_line(p1,p2,rouge);
		 
			}
			if(S.plan[i][j][1]==1)
			{
				POINT p1,p2;
				p1.x=i*50+50;
				p2.x=p1.x;
				p1.y=j*50;
				p2.y=p1.y+50;
				draw_line(p1,p2,rouge);
	        }
	        if(S.plan[i][j][2]==1)
	        {
				POINT p1,p2;
				p1.x=i*50;
				p2.x=p1.x+50;
				p1.y=j*50;
				p2.y=p1.y;
				draw_line(p1,p2,rouge);
			}
			if(S.plan[i][j][3]==1)
			{
				POINT p1,p2;
				p1.x=i*50;
				p2.x=p1.x;
				p1.y=j*50;
				p2.y=p1.y+50;
				draw_line(p1,p2,rouge);
			}
		}
	}
}

void afficher_le_slider(SLIDER S) 
{
	POINT p1;
	p1.x=(S.positionslider_x)*50+25;
	p1.y=(S.positionslider_y)*50+25;
	draw_fill_circle(p1,25,rouge);
}

void afficher_sortie(SLIDER S) 
{
	POINT p2;
	POINT p1;
	p1.x=(S.positionsortie_x)*50;
	p1.y=(S.positionsortie_y)*50;
	p2.x=((S.positionsortie_x)*50)+50;
	p2.y=((S.positionsortie_y)*50)+50;
	draw_fill_rectangle(p1,p2,vert);

}


void afficher_slider (SLIDER S) 
{
	afficher_grille(S);
	afficher_murs(S);
	afficher_le_slider(S);
	afficher_sortie(S);
}


void finir_affichage(SLIDER S) {
	wait_escape();
}



