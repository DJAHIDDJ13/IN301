void test(char *nom);
