#include <string.h>
#include "mes_types.h"
#include "lire_ecrire.h"
#include <uvsqgraphics.h>

#include "afficher.h"
#include "deplacement_slider.h"




void editeur(char*nom1,char*nom2)
{
	SLIDER S;
	POINT p,p2;
	int h=atoi(nom1);
	int b=atoi(nom2);
	S.L=h;
	S.H=b;
	initialiser_affichage(S);
	afficher_grille(S);
	p=wait_clic();
	S.positionslider_x=p.x/50;
	S.positionslider_y=p.y/50;
	afficher_le_slider(S);
	p2=wait_clic();
	S.positionsortie_x=p2.x/50;
	S.positionsortie_y=p2.y/50;
	afficher_sortie(S);
	S.nbr_mur=0;
	ecrire_fichier(S,"niveaucrée.c");
	S=init_tab(S);
	//S=initialisation_murs_externes(S);
	S.plan=malloc(sizeof(int**)*S.L);
	for(int i=0; i<S.L; i++)
	{
		S.plan[i]=malloc(sizeof(int*)*S.H);
		for(int j=0; j<S.H; j++)
		{
			S.plan[i][j]=malloc(sizeof(int)*4);
			for(int k=0; k<4; k++)
			{
				S.plan[i][j][k] = mur_externe(S, i, j, k);
				
			}
		}
	}
	
	deplace_slider(S);
	//slider_rencontre_sortie(S);
	wait_escape();
	
	
}

















