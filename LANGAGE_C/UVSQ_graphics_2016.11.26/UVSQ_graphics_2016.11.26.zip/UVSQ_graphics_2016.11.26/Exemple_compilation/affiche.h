void initialiser_affichage();
void ecrire_texte_dans_cercle(char *texte);
