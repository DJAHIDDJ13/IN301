#include "affiche.h"
#include <stdlib.h>

int main() {
    initialiser_affichage();
    ecrire_texte_dans_cercle("Bonjour le monde !");
    exit(0);
}
